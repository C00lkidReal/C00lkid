local StarterGui = game:GetService("StarterGui")

-- Display the "bytebreaker.cc injected" notification
StarterGui:SetCore("SendNotification", {
    Title = "bytebreaker.cc";
    Text = "injected";
    Duration = 5;
})